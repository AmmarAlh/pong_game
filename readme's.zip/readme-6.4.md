With this file you can run the following commands to generate and source the build, install, log files and directories for the application:

For the game screen the following commands should be used:

cd pong_ws/
colcon build
source ./install/setup.bash
ros2 run visualization game_render 


To test the visualization the next commands should be used inside a new terminal:
cd pong_ws/
colcon build
source ./install/setup.bash
ros2 run visualization game_state_publisher_node 

To test the ROS node connections the following command can be used inside a new window:
rqt_graph

