With this file you can run the following commands to generate and source the build, install, log files and directories for the application:

Pong core and visualization components can be launched using the commands below:

cd pong_ws/
colcon build
source ./install/setup.bash
ros2 launch pong_core pongcore.launch.py

To run the light blob detection the next command should be used inside a new terminal:
cd pong_ws/
source ./install/setup.bash
ros2 run advanced_user_interface light_blob_position 

In another terminal in combination with:
cd pong_ws/
source ./install/setup.bash
ros2 run advanced_user_interface light_position_detection 

To test the ROS node connections the following command can be used inside a new window:
rqt_graph
