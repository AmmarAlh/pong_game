With this file you can run the following commands to generate and source the build, install, log files and directories for the application:

cd pong_ws/
colcon build
source ./install/setup.bash
ros2 launch advanced_user_interface advanced_user_interface.launch.py

To test the ROS node connections the following command can be used inside a new window:
rqt_graph
