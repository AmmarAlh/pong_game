With this file you can run the following commands to generate and source the build, install, log files and directories for the application:

cd pong_ws/
colcon build
source ./install/setup.bash
ros2 run advanced_user_interface light_blob_oscillation_frequency

To test the ROS node connections the following command can be used inside a new window:
rqt_graph
